package com.hhs.FirstMod;

import java.util.HashSet;

import net.minecraft.item.Item;
import net.minecraft.item.ItemTool;

public class AdminTool extends ItemTool {
	public AdminTool(){
		super(99999f, ToolMaterial.GOLD, new HashSet());
        setHarvestLevel("pickaxe", 4);
        setHarvestLevel("shovel", 4);
        setHarvestLevel("axe", 4);
        setHarvestLevel("admintoollevel",200);
        setMaxDamage(0); 
        
	}
}
