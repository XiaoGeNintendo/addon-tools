package com.hhs.FirstMod;

import net.minecraft.block.material.Material;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;

public class BlockMaths extends BlockFluidClassic {

	public BlockMaths() {
		super(FirstMod.Maths, Material.water);
		// TODO Auto-generated constructor stub
	}

}
