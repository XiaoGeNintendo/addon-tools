package com.hhs.FirstMod;

import net.minecraft.block.Block;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBucket;

public class BucketMaths extends ItemBucket {

	public BucketMaths() {
		super(FirstMod.blockMaths);
		setContainerItem(Items.bucket);
		
	}

}
