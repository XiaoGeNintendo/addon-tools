package com.hhs.FirstMod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandom.Item;

public class ChangerContainer extends Container {
	private IInventory items=new InventoryBasic("Changer's GUI", true, 4);
	Slot slot1;
	Slot slot2;
	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		// TODO Auto-generated method stub
		return true;
	}
	
	public ChangerContainer(EntityPlayer player){
		super();
		this.addSlotToContainer(slot1=new Slot(items, 0,56, 30){

			@Override
			public void onSlotChanged() {
				// TODO Auto-generated method stub
				super.onSlotChanged();
				if(this.getStack()!=null){
					net.minecraft.item.Item item=this.getStack().getItem();
					int num=this.getStack().stackSize;
					
					if(item==net.minecraft.item.Item.getItemFromBlock(FirstMod.fakeFirstBlock) && num>=64){
						slot2.putStack(new ItemStack(FirstMod.firstBlock));
					}
				}
			}
			
		});
		this.addSlotToContainer(slot2=new Slot(items, 1, 56, 30){

			@Override
			public boolean isItemValid(ItemStack stack) {
				// TODO Auto-generated method stub
				return false;
			}
			
		});
		for (int i = 0; i < 3; ++i)
        {
            for (int j = 0; j < 9; ++j)
            {
                this.addSlotToContainer(new Slot(player.inventory, j + i * 9 + 9, 8 + j * 18, 74 + i * 18));
            }
        }

        for (int i = 0; i < 9; ++i)
        {
            this.addSlotToContainer(new Slot(player.inventory, i, 8 + i * 18, 132));
        }
        
	}

	@Override
	public void updateProgressBar(int id, int data) {
		// TODO Auto-generated method stub
		super.updateProgressBar(id, data);
	}
}
