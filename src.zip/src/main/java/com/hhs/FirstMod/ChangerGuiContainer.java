package com.hhs.FirstMod;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class ChangerGuiContainer extends GuiContainer {
	private static final String TexturePath="firstmod:textures/gui/container/changercontainer.png";
	private static final ResourceLocation Texture=new ResourceLocation(TexturePath);
	public static ChangerGuiContainer instance;
	int offsetX = (this.width - this.xSize) / 2, offsetY = (this.height - this.ySize) / 2;
	public ChangerGuiContainer(Container p_i1072_1_) {
		super(p_i1072_1_);
		xSize=176;
		ySize=156;
		instance=this;
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
		GlStateManager.color(1.0F, 1.0F, 1.0F);

        this.mc.getTextureManager().bindTexture(Texture);
        int offsetX = (this.width - this.xSize) / 2, offsetY = (this.height - this.ySize) / 2;

        this.drawTexturedModalRect(offsetX, offsetY, 0, 0, this.xSize, this.ySize);
	}
	
	@Override
	protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
    {
		
		String title = I18n.format("gui.firstmod.changergui");
        this.fontRendererObj.drawString(title, (this.xSize - this.fontRendererObj.getStringWidth(title)) / 2, 6, 0x404040);

        ItemStack item = new ItemStack(Items.bucket);
        ItemStack item2=new ItemStack(FirstMod.bucketMaths);
        ItemStack item3=new ItemStack(Items.milk_bucket);
        this.itemRender.renderItemAndEffectIntoGUI(item, 8, 12);
        this.itemRender.renderItemAndEffectIntoGUI(item2, 8, 28);
        this.itemRender.renderItemAndEffectIntoGUI(item3, 8, 28+16);
        
        
        
       
    }
	 
}
