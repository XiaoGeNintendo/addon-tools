package com.hhs.FirstMod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class CleverApple extends ItemFood {

	public CleverApple() {
		super(20, 1F, true);

	}

	@Override
	protected void onFoodEaten(ItemStack stack, World worldIn, EntityPlayer player) {
		// TODO Auto-generated method stub
		if (!worldIn.isRemote) {
			player.addPotionEffect(new PotionEffect(Potion.healthBoost.id, 100000, 255));
			player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 100000, 255));
			player.addPotionEffect(new PotionEffect(Potion.heal.id,100000,255));
			player.addExperience(32767);
		}
		super.onFoodEaten(stack, worldIn, player);
	}

}
