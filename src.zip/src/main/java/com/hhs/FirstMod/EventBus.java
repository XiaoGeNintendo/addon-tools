package com.hhs.FirstMod;
/**
 * <h1>>>>EVENT BUS>>></h1>
 * <code>Hey,do you want to visit our mod package?Come here and find all the JavaDoc we have written here!<br>P.S.:This class is useless</code>
 *<hr>
 *@see FirstMod
 *@see EventCentre
 *@see FML_EventSquare
 *@see ServerMall
 *@see LittleWorld
 */
public class EventBus {
	//LALALALALALAALALA
	//EVENT BUG SSJKLSJAIWQIDSAJFKLSA@#$%^&*()(&%$#@
}
