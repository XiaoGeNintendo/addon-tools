package com.hhs.FirstMod;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.DamageSource;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.EntityInteractEvent;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fluids.BlockFluidBase;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidContainerRegistry;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.Event.Result;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
/**
 * <h1>Event Center Welcome You!</h1>
 * <h2>This class is for the Mod Main Class:'First Mod'</h2>
 * <code>This class of code show the event which use EVENT_BUS to registry</code>
 * <br>
 * <code>You can find use FMLCommonHandler.instance().bus().register()'s event in FML_EventSquare</code>
 * <hr>
 * @see EventBus
 */
public class EventCentre {
	public EventCentre() {
		MinecraftForge.EVENT_BUS.register(this);
	//	FMLCommonHandler.instance().bus().register(this);
	}

	@SubscribeEvent
	public void onEntityInteract(EntityInteractEvent event) {
		EntityPlayer player = event.entityPlayer;
		if (player.isServerWorld()) {
			Entity pig = event.target;
			ItemStack stack = player.getCurrentEquippedItem();
			if (stack != null && (stack.getItem() == Item.getByNameOrId("minecraft:tnt"))) {
				player.attackEntityFrom((new DamageSource("eatingtnt")).setExplosion(), 20.0F);
				player.worldObj.createExplosion(pig, pig.posX, pig.posY, pig.posZ, 10.0F, true);
				pig.setDead();

			}
		}
	}

	@SubscribeEvent
	public void AttackEntityEvent(net.minecraftforge.event.entity.player.AttackEntityEvent event) {
		if (event.entityPlayer != null && !event.entityPlayer.worldObj.isRemote) {
			if (EnchantmentHelper.getEnchantmentLevel(31, event.entityPlayer.getHeldItem()) > 0) {
				event.target.setVelocity(0,
						0.75f * EnchantmentHelper.getEnchantmentLevel(31, event.entityPlayer.getHeldItem()), 0);
			}
			// event.entityPlayer.addChatMessage(new
			// ChatComponentText(String.valueOf(EnchantmentHelper.getEnchantmentLevel(31,
			// event.entityPlayer.getHeldItem()))));

		}
	}

	@SubscribeEvent
	public void LivingJumpEvent(net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent event) {
		PotionEffect effect = event.entityLiving.getActivePotionEffect(FirstMod.potionOfZhuangbi);
		if (effect != null) {
			event.entityLiving.setVelocity(0, 1.0f * (effect.getAmplifier() + 1), 0);
			if (event.entityLiving instanceof EntityPlayer) {
				EntityPlayer player = (EntityPlayer) event.entityLiving;
				if (!player.worldObj.isRemote) {
					player.addChatMessage(new ChatComponentTranslation("info.zhuangbi1"));
					player.addChatMessage(new ChatComponentTranslation("info.zhuangbi2"));

				}
			}
		}
	}
	
	@SubscribeEvent
	public void EntityItemPickupEvent(net.minecraftforge.event.entity.player.EntityItemPickupEvent event){
		Item item=event.item.getEntityItem().getItem();
		EntityPlayer player=event.entityPlayer;
		if(event.item.getEntityItem().getItem()==Item.getItemFromBlock(FirstMod.firstBlock)){
			event.entityPlayer.triggerAchievement(FirstMod.AchFirstByFirst);
		}
		if(item==Item.getItemFromBlock(FirstMod.fakeFirstBlock)){
			player.triggerAchievement(FirstMod.AchFool);
		}
	}
	
	 @SubscribeEvent
	    public void onFillBucket(FillBucketEvent event)
	    {
	        BlockPos blockpos = event.target.getBlockPos();
	        IBlockState blockState = event.world.getBlockState(blockpos);
	        Fluid fluid = FluidRegistry.lookupFluidForBlock(blockState.getBlock());
	        if (fluid != null && new Integer(0).equals(blockState.getValue(BlockFluidBase.LEVEL)))
	        {
	            FluidStack fluidStack = new FluidStack(fluid, FluidContainerRegistry.BUCKET_VOLUME);
	            event.world.setBlockToAir(blockpos);
	            event.result = FluidContainerRegistry.fillFluidContainer(fluidStack, event.current);
	            event.setResult(Result.ALLOW);
	        }
	    }
}
