package com.hhs.FirstMod;

import java.util.List;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;

public class ExplodeCommand extends CommandBase {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "explode";
	}

	@Override
	public String getCommandUsage(ICommandSender sender) {
		// TODO Auto-generated method stub
		return "command.explode.usage";
	}

	@Override
	public void execute(ICommandSender sender, String[] args) throws CommandException {
		if(args.length==0){
			throw new WrongUsageException("command.explode.exception.lengtherror");
		}else{
			for(String str:args){
				CommandBase.getPlayer(sender, str).attackEntityFrom(new DamageSource("fmexplode").setExplosion().setDifficultyScaled().setDamageAllowedInCreativeMode().setDamageBypassesArmor(), 1000.0f);
				CommandBase.getPlayer(sender, str).worldObj.createExplosion(CommandBase.getPlayer(sender, str), CommandBase.getPlayer(sender, str).posX,CommandBase.getPlayer(sender, str).posY, CommandBase.getPlayer(sender, str).posZ,1.0f, false);
			}
		}
		
	}

	@Override
	public int getRequiredPermissionLevel() {
		return 2;
	}

	@Override
	public List addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos) {
		if(args.length>0){
			String[] names=MinecraftServer.getServer().getAllUsernames();
			return CommandBase.getListOfStringsMatchingLastWord(args, names);
		}
		return null;
	}

}
