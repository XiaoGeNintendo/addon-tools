package com.hhs.FirstMod;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLServerStartedEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
/**
 * <h1>Welcome to FML_Event Square</h1>
 *<h2>This place to registry event which need FMLCommonHandler to post it.</h2>
 *<hr>
 *@see EventBus
 */
public class FML_EventSquare {
	public FML_EventSquare() {
	//	MinecraftForge.EVENT_BUS.register(this);
		FMLCommonHandler.instance().bus().register(this);
	}
	
	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void onKeyInput(KeyInputEvent event) {
		/*
		 * if (FirstMod.zhuangBiKey.isPressed()) { EntityPlayer player =
		 * Minecraft.getMinecraft().thePlayer; player.addPotionEffect(new
		 * PotionEffect(FirstMod.potionOfZhuangbi.id, 1000, 2));
		 * player.addChatMessage(new
		 * ChatComponentTranslation("info.startzhuangbi")); }
		 */
		if (FirstMod.zhuangBiKey.isPressed()) {
			EntityPlayer player = Minecraft.getMinecraft().thePlayer;
			player.addChatMessage(new ChatComponentTranslation("info.startzhuangbi"));
			player.addPotionEffect(new PotionEffect(FirstMod.potionOfZhuangbi.id, 1000, 2));
		}
	}
	
	
	@SubscribeEvent
	public void ItemSmeltedEvent(ItemSmeltedEvent event){
		if(event.smelting.getItem()==FirstMod.secondIngot){
			event.player.triggerAchievement(FirstMod.AchSecondAfterOnce);
		}
	}
	
	@SubscribeEvent
	public void ItemCraftedEvent(net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent event){
		Item i=event.crafting.getItem();
		EntityPlayer p=event.player;
		if(event.crafting.getItem()==Item.getItemFromBlock(FirstMod.lockBlock)){
			event.player.triggerAchievement(FirstMod.AchLockdown);
		}
		if(i==FirstMod.cleverApple){
			p.triggerAchievement(FirstMod.AchMakeYouClever);
		}
		if(i==FirstMod.superCoal){
			p.triggerAchievement(FirstMod.AchBurnAllDay);
		}
		if(i==FirstMod.adminTool){
			p.triggerAchievement(FirstMod.AchAdminHere);
		}
		if(i==FirstMod.flyStuff){
			p.triggerAchievement(FirstMod.AchFly);
		}
		if(i==FirstMod.tntStuff){
			p.triggerAchievement(FirstMod.AchBomb);
		}
	}
	
	
}
