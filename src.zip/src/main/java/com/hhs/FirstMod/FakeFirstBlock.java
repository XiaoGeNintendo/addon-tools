package com.hhs.FirstMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class FakeFirstBlock extends Block {

	public FakeFirstBlock() {
			super(Material.rock);
	        setHardness(1.5f);
	        setResistance(0f);
	        setLightLevel(1.0f);
	        setHarvestLevel("pickaxe", 3);
	        setStepSound(soundTypeStone) ;
	}
}
