package com.hhs.FirstMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class FirstBlock extends Block {

	public FirstBlock() {
			super(Material.rock);
	        setHardness(3f);
	        setResistance(10.0f);
	        setLightLevel(1.0f);
	        setHarvestLevel("pickaxe", 3);
	        setStepSound(soundTypeMetal) ;
	        
	}
}
