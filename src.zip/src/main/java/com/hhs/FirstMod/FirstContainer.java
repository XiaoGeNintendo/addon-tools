package com.hhs.FirstMod;

import javax.swing.plaf.basic.BasicComboBoxUI.ItemHandler;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.asm.transformers.ItemStackTransformer;

public class FirstContainer extends Container {
	private IInventory items = new InventoryBasic("Hello!", true, 4);
	Slot slot1;
	Slot slot2;
	Slot slot3;
	Slot slot4;

	public FirstContainer(EntityPlayer player) {
		super();

		this.addSlotToContainer(slot1 = new Slot(items, 0, 38 + 0 * 32, 20) {
			// Slot one!!
			@Override
			public int getItemStackLimit(ItemStack stack) {
				if (stack.getItem() == Item.getItemFromBlock(FirstMod.fakeFirstBlock)) {
					return 64;
				} else {
					if (stack.getItem() == Item.getItemFromBlock(FirstMod.firstBlock)
							|| stack.getItem() == FirstMod.secondIngot) {
						return 16;
					} else {
						return 0;
					}
				}

			}

			@Override
			public boolean isItemValid(ItemStack stack) {
				// TODO Auto-generated method stub
				if (stack.getItem() == Item.getItemFromBlock(FirstMod.fakeFirstBlock)
						|| stack.getItem() == Item.getItemFromBlock(FirstMod.firstBlock)
						|| stack.getItem() == (FirstMod.secondIngot)) {
					return true;
				} else {
					return false;
				}
			}

			@Override
			public void onSlotChanged() {
				super.onSlotChanged();
				Item item;
				int num;
				if (this.getStack() != null) {
					item = this.getStack().getItem();
					num = this.getStack().stackSize;
					if (item == Item.getItemFromBlock(FirstMod.fakeFirstBlock)) {
						if (num / 64 > 0) {
							slot2.putStack(new ItemStack(Items.diamond, num / 64));
						}
						if (num / 32 > 0) {
							slot3.putStack(new ItemStack(Items.gold_ingot, num / 32));
						}
						if (num / 16 > 0) {
							slot4.putStack(new ItemStack(Items.iron_ingot, num / 16));
						}
					}
					if (item == Item.getItemFromBlock(FirstMod.firstBlock) || item == FirstMod.secondIngot) {
						slot2.putStack(new ItemStack(Items.diamond, num));
						slot3.putStack(new ItemStack(Items.gold_ingot, num * 2));
						slot4.putStack(new ItemStack(Items.iron_ingot, num * 4));
					}
				}

			}

			@Override
			public void onPickupFromSlot(EntityPlayer playerIn, ItemStack stack) {
				// TODO Auto-generated method stub
				super.onPickupFromSlot(playerIn, stack);
				slot2.putStack(null);
				slot3.putStack(null);
				slot4.putStack(null);
			}

		});

		this.addSlotToContainer(slot2 = new Slot(items, 1, 38 + 1 * 32, 20) {

			@Override
			public void onPickupFromSlot(EntityPlayer playerIn, ItemStack stack) {
				slot1.putStack(null);
				slot3.putStack(null);
				slot4.putStack(null);
			}
			public boolean isItemValid(ItemStack stack) {
				return false;
			}

		});
		this.addSlotToContainer(slot3 = new Slot(items, 2, 38 + 2 * 32, 20) {
			@Override
			public void onPickupFromSlot(EntityPlayer playerIn, ItemStack stack) {
				slot1.putStack(null);
				slot2.putStack(null);
				slot4.putStack(null);
			}
			public boolean isItemValid(ItemStack stack) {
				return false;
			}
		});
		this.addSlotToContainer(slot4 = new Slot(items, 3, 38 + 3 * 32, 20) {
			@Override
			public void onPickupFromSlot(EntityPlayer playerIn, ItemStack stack) {
				slot1.putStack(null);
				slot3.putStack(null);
				slot2.putStack(null);
			}
			public boolean isItemValid(ItemStack stack) {
				return false;
			}
		});

		for (int i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(player.inventory, j + i * 9 + 9, 8 + j * 18, 51 + i * 18));
			}
		}

		for (int i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(player.inventory, i, 8 + i * 18, 109));
		}
	}

	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) {
		// TODO Auto-generated method stub
		return null;
	}

}
