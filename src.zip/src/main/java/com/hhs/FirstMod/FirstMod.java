package com.hhs.FirstMod;

import org.lwjgl.input.Keyboard;

import net.minecraft.block.Block;
//import net.java.games.input.Keyboard;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Achievement;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.AchievementPage;
import net.minecraftforge.fluids.FluidContainerRegistry;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
/**
 * <h1>First Mod By Hell Hole Studios</h1>
 *<br>
 *<h2>-By HHS.XGN-</h2>
 *<br>
 *<hr>
 *<code>Coder's Club</code>
 *<br>
 *How to name the variables: <br>
 *1.对于物品ID值，使用全部小写<br>
 *2.对于物品ID变量名，使用全部首字母大写+ID的方式<br>
 *3.对于类实例，使用驼峰命名法。<br>
 *4.类实例统一赋值<br>
 *5.类命名方法：<br>
 *(1).类名全部首字母大写<br>
 *(2)。如果是一个父类且有许多子类，在类名后加Main<br>
 *6.成就命名方式：Ach+成就名全大写<br>
 *7.按键命名方式：按键名全大写+Key<br>
 *8.命令命名方式：Com+命令类名去掉Command<br>
 *9.版本号计算方法(A.B.C)：<br>
 *(1).大更新时更新A部分（例如修复许多严重BUG，重新更改游戏机制或者是一件惊天动地的事）<br>
 *(2).新建一个新的类实例时更新B部分（例如添加新的物品或成就）<br>
 *(3)。每次启动测试Client即C版本号+1（例如填写本文）<br>
 *（4）.本文写于2.13.2<br>
 *<hr>
 *@see EventBus
 */
@Mod(modid="firstmod",name="FirstModByHHS",version="3.9.5")
public class FirstMod {
	//Here to spawn names
	//private static ServerProxy server;
	private static final String modID="firstmod";
	private static final String FirstBlockID="firstblock";
	private static final String SecondIngotID="secondingot";
	private static final String AdminToolID="admintool";
	private static final String LockBlockID="lockblock";
	private static final String FlyStuffID="flystuff";
	private static final String TntStuffID="tntstuff";
	private static final String FirstModTabID="firstmodtab";
	private static final String SuperCoalID="supercoal";
	private static final String CleverAppleID="cleverapple";
	private static final String StupidArmorHelmetID="stupidarmorhelmet";
	private static final String StupidArmorChestplateID="stupidarmorchestplate";
	private static final String StupidArmorLeggingsID="stupidarmorleggings";
	private static final String StupidArmorBootsID="stupidarmorboots";
	private static final int LetMobsFlyEnchantmentID=31;
	private static final int PotionOfZhuangbi=31;
	private static final String ZhuangbiKeyID="key.firstmod.zhuangbikey";
	private static final String KeyCategoriesID="key.categories.firstmod";
	private static final String AchFirstByFirstID="achievement.firstmod.firstbyfirst";
	private static final String AchSecondAfterOnceID="achievement.firstmod.secondafteronce";
	private static final String AchLockdownID="achievement.firstmod.lockdown";
	private static final String AchMakeYouCleverID="achievement.firstmod.makeyouclever";
	private static final String AchBurnAllDayID="achievement.firstmod.burnallday";
	private static final String AchFlyID="achievement.firstmod.fly";
	private static final String AchBombID="achievement.firstmod.bomb";
	private static final String AchAdminHereID="achievement.firstmod.adminhere";
	private static final String ExplodeCommandID="explode";
	private static final String FakeFirstBlockID="fakefirstblock"; 
	private static final String AchFoolID="fool";
	private static final String MathsID="maths";
	private static final String BlockMathsID="blockmaths";
	private static final String BucketMathsID="bucketmaths";
	//Here to create objects
	@Instance(FirstMod.modID)
	public static FirstMod mod;
	public static FirstBlock firstBlock;
	public static SecondIngot secondIngot;
	public static AdminTool adminTool;
	public static LockBlock lockBlock;
	public static MaterialOfLockBlock materialOfLockBlock;
	public static FlyStuff flyStuff;
	public static TNTStuff tntStuff;
	public static FirstModTab firstModTab;
	public static SuperCoal superCoal;
	public static CleverApple cleverApple;
	public static StupidArmorMain stupidArmorMain;
	public static StupidArmorHelmet stupidArmorHelmet;
	public static StupidArmorChestplate stupidArmorChestplate;
	public static StupidArmorLeggings stupidArmorLeggings;
	public static StupidArmorBoots stupidArmorBoots;
	public static LetMobsFlyEnchantment letMobsFlyEnchantment;
	public static PotionOfZhuangbi potionOfZhuangbi;
	public static KeyBinding zhuangBiKey; //P.s.:This field has no public class in its own file!
	public static Achievement AchFirstByFirst;
	public static Achievement AchSecondAfterOnce;
	public static Achievement AchLockdown;
	public static Achievement AchMakeYouClever;
	public static Achievement AchBurnAllDay;
	public static Achievement AchFly;
	public static Achievement AchBomb;
	public static Achievement AchAdminHere;
	public static AchievementPage AchPage;
	public static ExplodeCommand ComExplode;
	public static LittleWorld littleWorld;
	public static FakeFirstBlock fakeFirstBlock;
	public static Achievement AchFool;
	public static Maths Maths;
	public static BlockMaths blockMaths;
	public static BucketMaths bucketMaths;
	public static GuiLoader GuiLoader;
	public static OpenGuiCommand ComOpenGui;
	public static ChangerCommand ComChanger;
	@EventHandler
	public void FMLServerStartingEvent(net.minecraftforge.fml.common.event.FMLServerStartingEvent event){
		new ServerMall(event);
	}
	
	@EventHandler
	public void preLoad(FMLPreInitializationEvent event)
	{
		//Registry 'Zhuangbi's key'
		zhuangBiKey=new KeyBinding(FirstMod.ZhuangbiKeyID, Keyboard.KEY_Z, FirstMod.KeyCategoriesID);
		ClientRegistry.registerKeyBinding(zhuangBiKey);
		
		
		//Event
		EventCentre ec=new EventCentre();
		FML_EventSquare es=new FML_EventSquare();
		
		//Loader
		GuiLoader=new GuiLoader();
		
		//Registry 'Material of lock'
		materialOfLockBlock=new MaterialOfLockBlock();
		
		//Registry 'First Mod Tab'
		firstModTab=new FirstModTab();
				
		//Registry 'FirstBlock'
		firstBlock=new FirstBlock();
		firstBlock.setUnlocalizedName(modID+"."+FirstBlockID);
		firstBlock.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerBlock(firstBlock,"firstblock");
		ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(firstBlock), 0, new ModelResourceLocation(modID+":"+FirstBlockID, "inventory"));
		
		//Registry 'SecondIngot'
		secondIngot=new SecondIngot();
		secondIngot.setUnlocalizedName(modID+"."+SecondIngotID);
		secondIngot.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(secondIngot, "secondingot");
		ModelLoader.setCustomModelResourceLocation(secondIngot, 0, new ModelResourceLocation(modID+":"+SecondIngotID, "inventory"));
		
		//Registry 'AdminTool'
		adminTool=new AdminTool();
		adminTool.setUnlocalizedName(modID+"."+AdminToolID);
		adminTool.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(adminTool, "admintool");
		ModelLoader.setCustomModelResourceLocation(adminTool, 0, new ModelResourceLocation(modID+":"+AdminToolID, "inventory"));
		
		//Registry 'Lock'
		lockBlock=new LockBlock();
		lockBlock.setUnlocalizedName(modID+"."+LockBlockID);
		lockBlock.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerBlock(lockBlock,"lockblock");
		ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(lockBlock), 0, new ModelResourceLocation(modID+":"+LockBlockID, "inventory"));
		
		//Registry 'FLy Stuff'
		flyStuff=new FlyStuff();
		flyStuff.setUnlocalizedName(modID+"."+FlyStuffID);
		flyStuff.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(flyStuff, "flystuff");
		ModelLoader.setCustomModelResourceLocation(flyStuff, 0, new ModelResourceLocation(modID+":"+FlyStuffID, "inventory"));

		//Registry 'TNT Stuff'
		tntStuff=new TNTStuff();
		tntStuff.setUnlocalizedName(modID+"."+TntStuffID);
		tntStuff.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(tntStuff, "tntstuff");
		ModelLoader.setCustomModelResourceLocation(tntStuff, 0, new ModelResourceLocation(modID+":"+TntStuffID, "inventory"));
		
		//Registry 'Super coal'
		superCoal=new SuperCoal();
		superCoal.setUnlocalizedName(modID+"."+SuperCoalID);
		superCoal.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(superCoal, "supercoal");
		ModelLoader.setCustomModelResourceLocation(superCoal, 0, new ModelResourceLocation(modID+":"+SuperCoalID, "inventory"));
		
		//Registry 'Clever Apple'
		cleverApple=new CleverApple();
		cleverApple.setUnlocalizedName(modID+"."+CleverAppleID);
		cleverApple.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(cleverApple, "cleverapple");
		ModelLoader.setCustomModelResourceLocation(cleverApple, 0, new ModelResourceLocation(modID+":"+CleverAppleID, "inventory"));
		
		//Registry 'Stupid Armor List'
		stupidArmorHelmet=new StupidArmorHelmet();
		stupidArmorChestplate=new StupidArmorChestplate();
		stupidArmorLeggings=new StupidArmorLeggings();
		stupidArmorBoots=new StupidArmorBoots();
		stupidArmorHelmet.setUnlocalizedName(modID+"."+StupidArmorHelmetID);
		stupidArmorChestplate.setUnlocalizedName(modID+"."+StupidArmorChestplateID);
		stupidArmorLeggings=new StupidArmorLeggings();
		stupidArmorLeggings.setUnlocalizedName(modID+"."+StupidArmorLeggingsID);
		stupidArmorBoots=new StupidArmorBoots();
		stupidArmorBoots.setUnlocalizedName(modID+"."+StupidArmorBootsID);
		stupidArmorHelmet.setCreativeTab(firstModTab);
		stupidArmorChestplate.setCreativeTab(firstModTab);
		stupidArmorLeggings.setCreativeTab(firstModTab);
		stupidArmorBoots.setCreativeTab(firstModTab);
		GameRegistry.registerItem(stupidArmorHelmet, "stupidarmorhelmet");
		GameRegistry.registerItem(stupidArmorChestplate, "stupidarmorchestplate");
		GameRegistry.registerItem(stupidArmorLeggings, "stupidarmorleggings");
		GameRegistry.registerItem(stupidArmorBoots, "stupidarmorboots");
		ModelLoader.setCustomModelResourceLocation(stupidArmorHelmet, 0, new ModelResourceLocation(modID+":"+StupidArmorHelmetID, "inventory"));
		ModelLoader.setCustomModelResourceLocation(stupidArmorChestplate, 0, new ModelResourceLocation(modID+":"+StupidArmorChestplateID, "inventory"));
		ModelLoader.setCustomModelResourceLocation(stupidArmorLeggings, 0, new ModelResourceLocation(modID+":"+StupidArmorLeggingsID, "inventory"));
		ModelLoader.setCustomModelResourceLocation(stupidArmorBoots, 0, new ModelResourceLocation(modID+":"+StupidArmorBootsID, "inventory"));
		
		//Registry 'Let Mobs Fly Enchantment'
		letMobsFlyEnchantment=new LetMobsFlyEnchantment();
		Enchantment.addToBookList(letMobsFlyEnchantment);
		
		//Registry 'Potion of zhuangbi'
		potionOfZhuangbi=new PotionOfZhuangbi();
		
		//Registry 'Fake First Block'
		fakeFirstBlock=new FakeFirstBlock();
		fakeFirstBlock.setUnlocalizedName(modID+"."+FakeFirstBlockID);
		fakeFirstBlock.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerBlock(fakeFirstBlock,"fakefirstblock");
		ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(fakeFirstBlock), 0, new ModelResourceLocation(modID+":"+FakeFirstBlockID, "inventory"));
		
		//Registry 'Maths'
		Maths=new Maths();
		
		if (FluidRegistry.isFluidRegistered(Maths))
        {
            event.getModLog().info("Found fluid {}, the registration is canceled. ", Maths.getName());
            Maths = (com.hhs.FirstMod.Maths) FluidRegistry.getFluid(Maths.getName());
        }
        else
        {
            FluidRegistry.registerFluid(Maths);
        }
		blockMaths=new BlockMaths();
		blockMaths.setUnlocalizedName(modID+"."+BlockMathsID);
		blockMaths.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerBlock(blockMaths,"blockmaths");
		FluidLoader.registerFluidRender(blockMaths, "fluid_maths");
		bucketMaths=new BucketMaths();
		bucketMaths.setUnlocalizedName(modID+"."+BucketMathsID);
		bucketMaths.setCreativeTab(FirstMod.firstModTab);
		GameRegistry.registerItem(bucketMaths, "bucketmaths");
		ModelLoader.setCustomModelResourceLocation(bucketMaths, 0, new ModelResourceLocation(modID+":"+BucketMathsID, "inventory"));
		FluidContainerRegistry.registerFluidContainer(Maths, new ItemStack(bucketMaths),
                FluidContainerRegistry.EMPTY_BUCKET);
		/*-----------------------------------------------------------------------------*/
		//Achievement area
		AchFirstByFirst=new Achievement("achievement.firstmod.firstbyfirst", "firstmod.firstbyfirst", 0, 0, firstBlock, null);
		AchFirstByFirst.setSpecial().registerStat();
		AchSecondAfterOnce=new Achievement("achievement.firstmod.secondafteronce", "firstmod.secondafteronce",2, 0, secondIngot, AchFirstByFirst);
		AchSecondAfterOnce.registerStat();
		AchLockdown=new Achievement("achievement.firstmod.lockdown","firstmod.lockdown",-3,-3,lockBlock,null);
		AchLockdown.registerStat();
		AchMakeYouClever=new Achievement(AchMakeYouCleverID, "firstmod.makeyouclever", 2, -2, FirstMod.cleverApple, AchSecondAfterOnce);
		AchBurnAllDay=new Achievement(AchBurnAllDayID,"firstmod.burnallday",2, 2, FirstMod.superCoal, AchSecondAfterOnce);
		AchFly=new Achievement(AchFlyID,"firstmod.fly",4, -1, FirstMod.flyStuff, AchSecondAfterOnce);
		AchBomb=new Achievement(AchBombID,"firstmod.bomb",4, 1, FirstMod.tntStuff, AchSecondAfterOnce);
		AchAdminHere=new Achievement(AchAdminHereID,"firstmod.adminhere",4, 0, FirstMod.adminTool, AchSecondAfterOnce);
		AchMakeYouClever.setSpecial().registerStat();
		AchBurnAllDay.registerStat();
		AchFly.registerStat();
		AchBomb.registerStat();
		AchAdminHere.setSpecial().registerStat();
		AchFool=new Achievement(AchFoolID, "firstmod.fool", -2, -3, fakeFirstBlock, null);
		AchFool.registerStat();
		AchPage=new AchievementPage("FirstModByHHS", AchFirstByFirst,AchSecondAfterOnce,AchLockdown,AchFly,AchBomb,AchBurnAllDay,AchMakeYouClever,AchAdminHere,AchFool);
		AchievementPage.registerAchievementPage(AchPage);
		
		
		//Command Town
		ComExplode=new ExplodeCommand();
		ComOpenGui=new OpenGuiCommand();
		ComChanger=new ChangerCommand();
		//Add recipes of them
		GameRegistry.addSmelting(firstBlock, new ItemStack(secondIngot), 1000f);
		GameRegistry.addShapedRecipe(new ItemStack(adminTool,1), new Object[]{
				"XXX",
				"XYX",
				" Y ",
				'X',secondIngot,
				'Y',Item.getByNameOrId("minecraft:stick")
		});
		GameRegistry.addShapedRecipe(new ItemStack(lockBlock,8),new Object[]{
				"XXX",
				"XYX",
				"XXX",
				'X',Item.getByNameOrId("minecraft:obsidian"),
				'Y',secondIngot
		});
		GameRegistry.addShapedRecipe(new ItemStack(flyStuff), new Object[]{
				" X ",
				" Y ",
				" Y ",
				'X',secondIngot,
				'Y',Item.getByNameOrId("minecraft:stick")
		});
		GameRegistry.addShapedRecipe(new ItemStack(tntStuff), new Object[] {
			" X ",
			" Y ",
			" Y ",
			'X',Item.getByNameOrId("minecraft:tnt"),
			'Y',Item.getByNameOrId("minecraft:stick")
		});
        GameRegistry.addShapedRecipe(new ItemStack(stupidArmorHelmet), new Object[]
        {
                "###", "# #", '#', secondIngot
        });
        GameRegistry.addShapedRecipe(new ItemStack(stupidArmorChestplate), new Object[]
        {
                "# #", "###", "###", '#', secondIngot
        });
        GameRegistry.addShapedRecipe(new ItemStack(stupidArmorLeggings), new Object[]
        {
                "###", "# #", "# #", '#', secondIngot
        });
        GameRegistry.addShapedRecipe(new ItemStack(stupidArmorBoots), new Object[]
        {
                "# #", "# #", '#', secondIngot
        });
        
		GameRegistry.addShapelessRecipe(new ItemStack(superCoal), new Object[]{Item.getByNameOrId("minecraft:coal"),secondIngot});
		GameRegistry.addShapelessRecipe(new ItemStack(cleverApple), new Object[]{Item.getByNameOrId("minecraft:apple"),secondIngot});
		GameRegistry.registerFuelHandler(new FuelOfSuperCoal());
		//World Gen
		littleWorld=new LittleWorld();
		GameRegistry.registerWorldGenerator(littleWorld, 1);
	}
	 
	@EventHandler
	public void load(FMLInitializationEvent event)
	{
	}
	 
	@EventHandler
	public void postLoad(FMLPostInitializationEvent event)
	{
	}
	
	/*Useless Code Down here:
	 * public static class ServerProxy{
		public void loadModel(){}
	}
	
	public static class ClientProxy extends ServerProxy{
		public void loadModel(){
			super.loadModel();
			ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(firstBlock), 0, new ModelResourceLocation(modID+":"+FirstBlockID, "inventory"));
			ModelLoader.setCustomModelResourceLocation(secondIngot, 0, new ModelResourceLocation(modID+":"+SecondIngotID, "inventory"));
		}
	}*/
	
}
