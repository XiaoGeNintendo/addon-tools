package com.hhs.FirstMod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class FirstModTab extends CreativeTabs {

	public FirstModTab() {
		super("firstmodtab");
	}

	@Override
	public Item getTabIconItem() {
		// TODO Auto-generated method stub
		return Item.getItemFromBlock(FirstMod.firstBlock);
	}

	@Override
	public boolean hasSearchBar() {
		// TODO Auto-generated method stub
		return true;
	}

	
}
