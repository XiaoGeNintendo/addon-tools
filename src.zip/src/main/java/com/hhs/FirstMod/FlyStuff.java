package com.hhs.FirstMod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;

public class FlyStuff extends Item {

	@Override
	public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
		// TODO Auto-generated method stub
		stack.damageItem(1,player);
		if (entity.worldObj.isRemote) {
	        return true;
	    }
		float rad = (player.rotationYaw/ 180f) * 3.141593f;
		float x = 3f * -MathHelper.sin(rad);
		float y=3f;
		float z = 3f * MathHelper.cos(rad);
		entity.setVelocity(x, y, z);
		return true;
	}

}
