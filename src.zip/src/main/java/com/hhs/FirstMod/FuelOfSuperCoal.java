package com.hhs.FirstMod;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.IFuelHandler;

public class FuelOfSuperCoal implements IFuelHandler {

	@Override
	public int getBurnTime(ItemStack fuel) {
		// TODO Auto-generated method stub
		if(fuel.getItem()==FirstMod.superCoal){
			return 999999;
		}else{
			return 0;
		}
	}

}
