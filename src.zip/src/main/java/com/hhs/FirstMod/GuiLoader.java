package com.hhs.FirstMod;

import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;

public class GuiLoader implements IGuiHandler {
	//GUI ID's
	public static final int FirstGuiID=1;
	public static final int ChangerGuiID=2;
	public GuiLoader(){
		NetworkRegistry.INSTANCE.registerGuiHandler(FirstMod.mod, this);
	}
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		switch(ID){
		case 1:
			return new FirstContainer(player);
		case 2:
			return new ChangerContainer(player);
		default:
			return null;	
		}
	}

	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		// TODO Auto-generated method stub
		switch(ID){
		case 1:
			return new FirstGuiContainer(new FirstContainer(player));
		case 2:
			return new ChangerGuiContainer(new ChangerContainer(player));
		default:
			return null;	
		}
	}

}
