package com.hhs.FirstMod;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.ResourceLocation;

public class LetMobsFlyEnchantment extends Enchantment {
	public LetMobsFlyEnchantment() {
		super(31, new ResourceLocation("firstmod:letmobsflyenchantment"), 3, EnumEnchantmentType.WEAPON);
		setName("letmobsfly");
	}

	@Override
	public int getMaxLevel() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public int getMinEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return 30;
	}

	@Override
	public int getMaxEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public boolean canApplyTogether(Enchantment ench) {
		// TODO Auto-generated method stub
		return true;
	}

	

	@Override
	public boolean isAllowedOnBooks() {
		// TODO Auto-generated method stub
		return true;
	}

}
