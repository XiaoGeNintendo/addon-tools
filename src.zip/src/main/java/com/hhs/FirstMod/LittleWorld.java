package com.hhs.FirstMod;

import java.util.Random;

import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;
/**
 * <h1>Little World!</h1>
 * <code>This class to spawn ores etc.</code>
 *<hr>
 *@see EventBus
 */
public class LittleWorld implements IWorldGenerator {
	public final WorldGenMinable FirstBlockGen=new WorldGenMinable(FirstMod.firstBlock.getDefaultState(), 3);
	public final WorldGenMinable FakeFirstBlockGen=new WorldGenMinable(FirstMod.fakeFirstBlock.getDefaultState(),10);
	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator,
			IChunkProvider chunkProvider) {
		if (world.provider.getDimensionId() != 0) {
			return;
		}
		//Gen First Block
		for (int i = 1; i <= 1; i++) {
			int posX = chunkX * 16 + random.nextInt(16);
			int posY = 1 + random.nextInt(9);
			int posZ = chunkZ * 16 + random.nextInt(16);
			BlockPos bp=new BlockPos(posX, posY, posZ);
			FirstBlockGen.generate(world, random, bp);
		}
		
		//Gen Fake First Block
		for(int i=1;i<=6;i++){
			int posX = chunkX * 16 + random.nextInt(16);
			int posY = 1 + random.nextInt(255);
			int posZ = chunkZ * 16 + random.nextInt(16);
			BlockPos bp=new BlockPos(posX, posY, posZ);
			FakeFirstBlockGen.generate(world, random, bp);
		}
	}

}
