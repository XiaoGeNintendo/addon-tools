package com.hhs.FirstMod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class LockBlock extends Block {

	public LockBlock() {
			super(FirstMod.materialOfLockBlock);
	        setHardness(20.0f);
	        setResistance(999999f);
	        setLightLevel(1.0f);
	        setHarvestLevel("admintoollevel", 1);
	        setStepSound(soundTypeStone) ;
	        
	}
}
