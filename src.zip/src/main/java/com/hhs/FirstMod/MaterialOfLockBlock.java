package com.hhs.FirstMod;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class MaterialOfLockBlock extends Material {

	public MaterialOfLockBlock(){
		   super(MapColor.blackColor); //设置它在地图上的颜色
	       setRequiresTool(); //让它只能被特定工具采集
	       setImmovableMobility();
	}

}
