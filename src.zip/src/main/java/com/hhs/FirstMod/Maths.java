package com.hhs.FirstMod;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.Fluid;

public class Maths extends Fluid {

	public Maths() {
		super("maths",new ResourceLocation("firstmod:fluid/maths_still"), new ResourceLocation("firstmod:fluid/maths_flowing"));
		this.setDensity(10000);
        this.setViscosity(50);
        this.setLuminosity(15);
        this.setTemperature(1000);
	}

}
