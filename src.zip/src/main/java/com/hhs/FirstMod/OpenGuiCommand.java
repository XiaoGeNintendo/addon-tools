package com.hhs.FirstMod;

import java.util.List;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.DamageSource;

public class OpenGuiCommand extends CommandBase {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "fmopengui";
	}

	@Override
	public String getCommandUsage(ICommandSender sender) {
		// TODO Auto-generated method stub
		return "command.fmopengui.usage";
	}

	@Override
	public void execute(ICommandSender sender, String[] args) throws CommandException {
		if(args.length>0){
			throw new WrongUsageException("command.fmopengui.exception.lengtherror");
		}else{
			EntityPlayer p=getCommandSenderAsPlayer(sender);
			p.openGui(FirstMod.mod, 1, p.worldObj,(int) p.posX,(int) p.posY,(int) p.posZ);
			p.addChatComponentMessage(new ChatComponentTranslation("command.fmopengui.info",p.getName()));
		}
		
	}

	@Override
	public int getRequiredPermissionLevel() {
		return 1;
	}


}
