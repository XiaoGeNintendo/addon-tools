package com.hhs.FirstMod;

import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;

public class PotionOfZhuangbi extends Potion {

	protected PotionOfZhuangbi() {
		super(31, new ResourceLocation("firstmod:potionofzhuangbi"),false,0x7F0000);
		setPotionName("potion.potionofzhuangbi");
		this.setIconIndex(0, 0);
		// TODO Auto-generated constructor stub
	}

}
