package com.hhs.FirstMod;

import net.minecraft.item.Item;

public class SecondIngot extends Item {
	public SecondIngot(){
		
	}
}
