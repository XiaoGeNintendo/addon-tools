package com.hhs.FirstMod;

import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/**
 * <h1>Server Mall is welcoming you</h1>
 * <h2>Hey,the guy over there,do you want a SUPER server to play MC with your friends?</h2>
 * <code>This class is used to do server events</code>
 *<hr>
 */
public class ServerMall {
	public ServerMall(FMLServerStartingEvent event){
		event.registerServerCommand(FirstMod.ComExplode);
		event.registerServerCommand(FirstMod.ComOpenGui);
		event.registerServerCommand(FirstMod.ComChanger);
	}
}
