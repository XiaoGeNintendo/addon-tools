package com.hhs.FirstMod;

public class StupidArmorBoots extends StupidArmorMain {

	public StupidArmorBoots() {
		super(3);
	}
	
}
