package com.hhs.FirstMod;

public class StupidArmorChestplate extends StupidArmorMain {

	public StupidArmorChestplate() {
		super(1);
	}
	
}
