package com.hhs.FirstMod;

public class StupidArmorHelmet extends StupidArmorMain {

	public StupidArmorHelmet() {
		super(0);
	}
	
}
