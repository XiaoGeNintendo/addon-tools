package com.hhs.FirstMod;

public class StupidArmorLeggings extends StupidArmorMain {

	public StupidArmorLeggings() {
		super(2);
	}
	
}
