package com.hhs.FirstMod;

import net.minecraft.item.ItemArmor;
import net.minecraftforge.common.util.EnumHelper;

public class StupidArmorMain extends ItemArmor {
	public static final ArmorMaterial StupidArmorMaterial=EnumHelper.addArmorMaterial("stupid", "firstmod:stupid", 99, new int[]{5,5,5,5}, 99);
	public StupidArmorMain(int armorType) {
		super(StupidArmorMaterial, StupidArmorMaterial.ordinal(), armorType);
	}

}

