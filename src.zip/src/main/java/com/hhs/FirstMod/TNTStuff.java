package com.hhs.FirstMod;

import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class TNTStuff extends Item {

	@Override
	public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn) {
		// TODO Auto-generated method stub
		EntityTNTPrimed tnt=new EntityTNTPrimed(worldIn,playerIn.posX,playerIn.posY+10,playerIn.posZ,playerIn);
		tnt.fuse=100;
		worldIn.spawnEntityInWorld(tnt);
		return itemStackIn;
	}
	/*
	 * public TNTStuff() { // TODO Auto-generated constructor stub }
	 * 
	 * @Override public void onPlayerStoppedUsing(ItemStack stack, World
	 * worldIn, EntityPlayer playerIn, int timeLeft) { // TODO Auto-generated
	 * method stub if(!worldIn.isRemote){ EntityTNTPrimed tnt=new
	 * EntityTNTPrimed(worldIn,playerIn.posX,playerIn.posY,playerIn.posZ,
	 * playerIn); tnt.fuse=getMaxItemUseDuration(stack)-timeLeft;
	 * worldIn.spawnEntityInWorld(tnt); } }
	 * 
	 * @Override public EnumAction getItemUseAction(ItemStack stack) { // TODO
	 * Auto-generated method stub return EnumAction.BLOCK; }
	 * 
	 * @Override public int getMaxItemUseDuration(ItemStack stack) { // TODO
	 * Auto-generated method stub return 10000; }
	 * 
	 * @Override public void onUsingTick(ItemStack stack, EntityPlayer player,
	 * int count) { stack.damageItem(1, player); }
	 */

}
