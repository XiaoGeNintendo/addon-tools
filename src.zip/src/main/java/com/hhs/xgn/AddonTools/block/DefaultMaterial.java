package com.hhs.xgn.AddonTools.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class DefaultMaterial extends Material {

	public DefaultMaterial() {
		super(MapColor.diamondColor);
	}

}
