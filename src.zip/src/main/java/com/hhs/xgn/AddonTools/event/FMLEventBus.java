package com.hhs.xgn.AddonTools.event;

import com.hhs.xgn.AddonTools.achievement.AchievementMainClass;
import com.hhs.xgn.AddonTools.block.BlockLoader;
import com.hhs.xgn.AddonTools.item.ItemTown;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FMLEventBus {
	public FMLEventBus(){
		FMLCommonHandler.instance().bus().register(this);
	}
	
	@SubscribeEvent
	public void ItemCraftedEvent(net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent event){
		if(event.crafting.getItem().equals(ItemTown.dh)){
			event.player.triggerAchievement(AchievementMainClass.a);
		}
		if(event.crafting.getItem().equals(ItemTown.fw)){
			event.player.triggerAchievement(AchievementMainClass.b);
		}
		if(event.crafting.getItem().equals(ItemTown.ls)){
			event.player.triggerAchievement(AchievementMainClass.c);
		}
		if(event.crafting.getItem().equals(ItemTown.up)){
			event.player.triggerAchievement(AchievementMainClass.d);
		}
		if(event.crafting.getItem().equals(ItemTown.ln)){
			event.player.triggerAchievement(AchievementMainClass.e);
		}
		Item i=event.crafting.getItem();
		EntityPlayer p=event.player;
		if(i.equals(ItemTown.uc)){
			p.triggerAchievement(AchievementMainClass.f);
		}
		if(i.equals(ItemTown.ic)){
			p.triggerAchievement(AchievementMainClass.g);
		}
		if(i.equals(ItemTown.imc)){
			p.triggerAchievement(AchievementMainClass.h);
		}
		if(i.equals(ItemTown.ne)){
			p.triggerAchievement(AchievementMainClass.i);
		}
		if(i.equals(ItemTown.vb)){
			p.triggerAchievement(AchievementMainClass.j);
		}
		if(i.equals(ItemTown.ew)){
			p.triggerAchievement(AchievementMainClass.k);
		}
		if(i.equals(ItemTown.el)){
			p.triggerAchievement(AchievementMainClass.l);
		}
		if(i.equals(ItemTown.ds)){
			p.triggerAchievement(AchievementMainClass.m);
		}
		if(i.equals(ItemTown.ws)){
			p.triggerAchievement(AchievementMainClass.n);
		}
		if(i.equals(ItemTown.ls_)){
			p.triggerAchievement(AchievementMainClass.o);
		}
		if(i.equals(ItemTown.ms)){
			p.triggerAchievement(AchievementMainClass.p);
		}
		if(i.equals(ItemTown.rc)){
			p.triggerAchievement(AchievementMainClass.q);
		}
		if(i.equals(ItemTown.is)){
			p.triggerAchievement(AchievementMainClass.r);
		}
		if(i.equals(Item.getItemFromBlock(BlockLoader.r))){
			p.triggerAchievement(AchievementMainClass.s);
		}
	}
}
