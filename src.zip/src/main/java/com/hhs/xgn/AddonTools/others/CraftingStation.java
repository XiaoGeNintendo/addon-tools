package com.hhs.xgn.AddonTools.others;

import com.hhs.xgn.AddonTools.block.BlockLoader;
import com.hhs.xgn.AddonTools.item.ItemTown;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CraftingStation {
	public CraftingStation(){
		ItemStack lapis=new ItemStack(Item.getByNameOrId("351"));
		lapis.setItemDamage(4);
		//TODO ADD CRAFTING HERE
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.up,1),new Object[]{"aaa","aaa","aaa",'a',Items.diamond_pickaxe});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ne,1), new Object[]{"aaa","aaa","aaa",'a',Items.diamond_shovel});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.fw,1), new Object[]{"aaa","aaa","aaa",'a',Items.diamond_axe});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ls,1), new Object[]{"aaa","aaa","aaa",'a',Items.diamond_sword});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.dh,1), new Object[]{"aaa","aaa","aaa",'a',Items.diamond_hoe});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ew), new Object[]{"aaa","aaa","aaa",'a',Items.water_bucket});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.el), new Object[]{"aaa","aaa","aaa",'a',Items.lava_bucket});
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.ln,9),lapis);
		GameRegistry.addShapedRecipe(lapis, new Object[]{"aaa","aaa","aaa",'a',ItemTown.ln});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.uc,3), new Object[]{
				"aba",
				"bcb",
				"aba",
				'a',Items.gold_nugget,
				'b',ItemTown.ln,
				'c',Item.getItemFromBlock(Blocks.iron_block)
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.vb,1),new Object[]{
			"aaa",
			"aba",
			"aaa",
			'a',Items.bucket,
			'b',ItemTown.uc
		});
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.ic),new ItemStack(Items.cake,1),new ItemStack(ItemTown.uc,1));
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ic),new Object[]{
				"aaa",
				"aba",
				"aaa",
				'a',Items.bread,
				'b',ItemTown.uc
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ws,8),new Object[]{
				"aaa",
				"aba",
				"aaa",
				'a',ItemTown.ds,
				'b',Items.water_bucket
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ls_,8),new Object[]{
				"aaa",
				"aba",
				"aaa",
				'a',ItemTown.ds,
				'b',Items.lava_bucket
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.ms,8),new Object[]{
				"aaa",
				"aba",
				"aaa",
				'a',ItemTown.ds,
				'b',Items.milk_bucket
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.rc),new Object[]{
			"aab",
			"aab",
			"bbc",
			'a',Items.gold_ingot,
			'b',Items.nether_star,
			'c',Item.getItemFromBlock(Blocks.iron_block)
		});
		GameRegistry.addShapedRecipe(new ItemStack(ItemTown.is,8),new Object[]{
				"aaa",
				"aba",
				"aaa",
				'a',ItemTown.ds,
				'b',Items.dye
		});
		GameRegistry.addShapedRecipe(new ItemStack(BlockLoader.r,1),new Object[]{
				"aba",
				"aca",
				"aba",
				'a',ItemTown.rc,
				'b',ItemTown.uc,
				'c',Blocks.iron_block
		});
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.imc),new ItemStack(ItemTown.uc,1),new ItemStack(Items.bone,1),new ItemStack(ItemTown.ic));
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.imc),new ItemStack(ItemTown.uc,1),new ItemStack(Items.beef,1),new ItemStack(ItemTown.ic));
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.imc),new ItemStack(ItemTown.uc,1),new ItemStack(Items.porkchop,1),new ItemStack(ItemTown.ic));
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.imc),new ItemStack(ItemTown.uc,1),new ItemStack(Items.mutton,1),new ItemStack(ItemTown.ic));
		GameRegistry.addShapelessRecipe(new ItemStack(ItemTown.ds),new ItemStack(Items.stick));
		
	}
	private void sr(ItemStack i,Object... o){
		GameRegistry.addShapedRecipe(i, o);
	}
}
