package com.hhs.xgn.AddonTools.others;

public class TabLoader {
	public static AddonToolsTab tab;
	public TabLoader(){
		tab=new AddonToolsTab();
		
	}
}
